<?php

// UPLOAD PROGRESS MATERIAL
function UploadImage_pros($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_promat/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload1"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prod($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_promat/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload2"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prot($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_promat/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload3"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_proe($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_promat/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload4"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prol($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_promat/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload5"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

// AKHIR UPLOAD PROGRESS MATERIAL
/////////////////////////////////////////////////////////////////////////////////////////////
// UPLOAD PROGRESS FISIK

function UploadImage_prs($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_profis/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload1"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prd($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_profis/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload2"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prt($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_profis/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload3"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_pre($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_profis/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload4"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

function UploadImage_prl($fupload_name){
  //direktori gambar
  $vdir_upload = "../../../foto_profis/";
  $vfile_upload = $vdir_upload . $fupload_name;

  //Simpan gambar dalam ukuran sebenarnya
  move_uploaded_file($_FILES["fupload5"]["tmp_name"], $vfile_upload);

  //identitas file asli
  $im_src = imagecreatefromjpeg($vfile_upload);
  $src_width = imageSX($im_src);
  $src_height = imageSY($im_src);

  //Hapus gambar di memori komputer
  imagedestroy($im_src);
}

// AKHIR UPLOAD PROGRESS FISIK

?>
