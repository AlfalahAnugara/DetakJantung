<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "data_jantung";
// set_time_limit(1800);
$koneksi = mysqli_connect($server,$user,$password,$database) or die ("Koneksi gagal");
// mysqli_select_db($koneksi,$database) or die ("Database tidak ditemukan");
?>
