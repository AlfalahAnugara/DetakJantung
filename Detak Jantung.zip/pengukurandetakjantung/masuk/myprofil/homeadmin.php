


<html>
<head><title>ADAM ABDI AL A'LA</title></head>
<link rel="stylesheet" type="text/css" href="css/demo1.css" />
<link rel="stylesheet" type="text/css" href="css/style33.css" />
<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" type="text/css" href="css/style2.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="front.css" media="screen, projection" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/metro-bootstrap.css">
<body>

			

<br>
<br>
	<table width="100%">
   	  <tr>
        <td class="container">
			<header>
				<h1 align="center">ADAM <span>ABDI AL A'LA</span></h1>
			</header>         </td>
        </tr>
</table>
<section class="wrapper">
		
<div id="ad-1">
					<div id="content">
						<h2>Welcome!!!</h2>
					  <h3>Relax - we've got your rudder.</h3>
                        <h5>Adam_Corporation.</h5>
						<form>
							<input type="text" id="email" value="Email address..." />
							<input type="submit" id="submit" value="Guide me" />
						</form>
					</div>
					<div id="clouds">
						<ul id="cloud-group-1">
							<li class="cloud-1"></li>
							<li class="cloud-2"></li>
							<li class="cloud-3"></li>
						</ul>
						<ul id="cloud-group-2">
							<li class="cloud-1"></li>
							<li class="cloud-2"></li>
							<li class="cloud-3"></li>
						</ul>
					</div>
					<ul id="boat">
						<li>
							<div id="question-mark"></div>
						</li>
					</ul>
					<ul id="water">
						<li id="water-back"></li>
						<li id="water-front"></li>
					</ul>
  </div>
</section> 
<center>
<a href="" class="btn btn-lg btn-success"><img src="TwitterIcon.png" width="20" height="20"> @Adam_Adifa</a>
		      &nbsp;
	      <a href="" class="btn btn-lg btn-info"><img src="BBM-Logo-300x300.png " width="20" height="20">75BA7453</a>
          <a href="" class="btn btn-lg btn-danger"><img src="url2.png" width="20" height="20">adam.adifakenshi@gmail.com</a>
</body>
</html>
