<?php
include "../configurasi/koneksi.php";
include "../configurasi/library.php";
include "../configurasi/fungsi_indotgl.php";
include "../configurasi/fungsi_combobox.php";

if ($_GET['module']=='home'){

     $non=mysqli_query($koneksi,"SELECT * FROM onoff");
	 $hnon=mysqli_fetch_array($non);
	 $nnon = $hnon['stt'];
	 
	?>
		<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">DATA PROSES BPM</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div>
				</div>
				<div class="box-body">
				
				<a  class ='btn  btn-danger btn-flat' href='aksi_onoff.php?stt=<?php echo $nnon ?>'><?php echo $nnon ?></a>

				<br><br>

				<form method="POST" action="aksi_naive.php" enctype="multipart/form-data" class="form-horizontal">
						
							  <div class="form-group">
									<label class="col-sm-2 control-label">Status MQTT server </label>        		
									 <div class="col-sm-6">
										<input type="text" name="ws" id="ws" class="form-control">
									 </div>
							  </div>
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Kode Proses </label>        		
									 <div class="col-sm-6">
										<input type="text" name="kd_proses" id="kd_proses" class="form-control" required="required" value="<?php echo date('dmYhis'); ?>">
									 </div>
							  </div>
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Nama Pasien </label>        		
									 <div class="col-sm-6">
										<input type="text" name="nm_pasien" id="nm_pasien" class="form-control">
									 </div>
							  </div>
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Usia </label>        		
									 <div class="col-sm-1">
										<input type="text" name="usia" id="usia" class="form-control" required="required">
									 </div>
									 <div class="col-sm-1">
										<label class="col-sm-1 control-label">*Tahun </label>
									 </div>
							  </div>
							  
							  <div class="buttons">
							  <a class ="btn  btn-success btn-flat" onclick="reply_click();">PROSES HASIL SCAN</a>
							  <input class="btn btn-primary" type="submit" value="PROSES NAIVE BAYES">
							  </div>
							  </form>
				
				
				<div id="tabeldetik">
                
                </div>
				
				</div>
				</div>
				
	   
	   
	 
  <?php
  
}
// Bagian profil
elseif ($_GET['module']=='profil'){
   include "modul/mod_profil/profil.php";
}

// set kelas
elseif ($_GET['module']=='kelas'){
   include "modul/mod_kelas/kelas.php";
}

// set hasil
elseif ($_GET['module']=='hasil'){
   include "modul/mod_hasil/hasil.php";
}

// set histori
elseif ($_GET['module']=='histori'){
   include "modul/mod_histori/histori.php";
}
elseif ($_GET['module']=='deletehistori'){
   include "modul/mod_histori/aksi_histori.php";
}

// set tabel
elseif ($_GET['module']=='tabel'){
	include "modul/mod_tabel/tabel.php";
 }

// set pasien perhitungan
elseif ($_GET['module']=='perhitungan'){
	include "modul/mod_perhitungan/perhitungan.php";
 }

 // set hitung perhitungan
elseif ($_GET['module']=='hitung'){
	include "modul/mod_perhitungan/aksi_perhitungan.php";
 }






?>

<script>

var myVarD;
var myVarM;
var mqtt;
var reconnectTimeout = 1000;



$(document).ready(function() {
        MQTTconnect();
    });
        
		
function MQTTconnect() {
	mqtt = new Paho.MQTT.Client(host,port,'mqtt');
        var options = {
            timeout: 3,
            useSSL: useTLS,
            cleanSession: cleansession,
            onSuccess: onConnect,
            onFailure: function (message) {
                $('#ws').val("Connection failed: " + message.errorMessage + "Retrying");
                setTimeout(MQTTconnect, reconnectTimeout);
            }
        };
		
        mqtt.onConnectionLost = onConnectionLost;
        mqtt.onMessageArrived = onMessageArrived;
        if (username != null) {
            options.userName = username;
            options.password = password;
        }
        console.log("Host="+ host + ", port=" + port);
        mqtt.connect(options);
    };

    function onConnect() {
		mqtt.subscribe(topic, {qos: 0});
        $('#ws').val('Connected to ' + host + ':' + port + ' Topic: ' + topic);
    };

    function onConnectionLost(response) {
        setTimeout(MQTTconnect, reconnectTimeout);
        $('#ws').val("connection lost: " + responseObject.errorMessage + ". Reconnecting");

    };
	
	

    function onMessageArrived(message) {
	
        var topic = message.destinationName;
        var payload = message.payloadString;
		
		$.ajax({
                url: 'kirimdata.php',
                type: 'post',
				data: {'hbpm': payload },
                success: function(data) {
                }
				
            });
			
    };

    
	function reply_click(){

    updateD();
	
	var kd_proses = document.getElementById('kd_proses').value;
	var nm_pasien = document.getElementById('nm_pasien').value;
	var usia = document.getElementById('usia').value;
	
			//
			$.ajax({
					type: 'post',
					url: "aksi_proses.php",
					data: {'nm_pasien': nm_pasien, 'usia': usia, 'kd_proses': kd_proses },
                    success: function(data) {
                    alert('proses selesai');
					clearTimeout(myVarD);
                    }
					});
					}
					
		
        

        function updateD() {

		var kd_proses2 = document.getElementById('kd_proses').value;
		
            $.ajax({
                url: 'tbldetik.php',
                type: 'post',
				data: {'kd_proses2': kd_proses2 },
                success: function(data) {
                    $('#tabeldetik').html(data);
                }
				
            });
			myVarD = setTimeout(updateD, 250);
        }
		
</script>
