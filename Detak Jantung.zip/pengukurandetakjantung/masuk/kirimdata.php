<?php
include "../configurasi/koneksi.php";

$nilai = $_POST['hbpm'];


$login=mysqli_query($koneksi,"SELECT * FROM onoff WHERE stt='ON'");
$ketemu=mysqli_num_rows($login);
if ($ketemu > 0){

	if($nilai > 200){

	}else{
	mysqli_query($koneksi,"INSERT INTO simsen(hsl)
	VALUES('$nilai')");

	}

	

}else{

}
			   
?>
