host = '127.0.0.1';
port = 8083;
topic = 'Jantung';
useTLS = false;
username = null;
password = null;

cleansession = true;
