<?php
include "../configurasi/koneksi.php";
include "../configurasi/fungsi_thumb.php";
include "../configurasi/library.php";
include "../configurasi/koneksi.php";

	$kd_proses = $_POST['kd_proses'];

	$avgnormal=mysqli_query($koneksi,"SELECT AVG(nilai_bpm) AS avn FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='NORMAL'");
	$nilainormal=mysqli_fetch_array($avgnormal);
	$hslavgn = $nilainormal['avn'];
	
	$avgtdknormal=mysqli_query($koneksi,"SELECT AVG(nilai_bpm) AS avtn FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='TIDAK NORMAL'");
	$nilaitdknormal=mysqli_fetch_array($avgtdknormal);
	$hslavgtn = $nilaitdknormal['avtn'];

	mysqli_query($koneksi,"INSERT INTO mean(unik_pasien,kelas,n_average) VALUES('$kd_proses','NORMAL','$hslavgn')");
							  
	mysqli_query($koneksi,"INSERT INTO mean(unik_pasien,kelas,n_average) VALUES('$kd_proses','TIDAK NORMAL','$hslavgtn')");
							  



	$cek1=mysqli_query($koneksi,"SELECT * FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='NORMAL'");
    $ketemu1=mysqli_num_rows($cek1);
	if ($ketemu1 > 0){

		$dtjmlnormal=mysqli_query($koneksi,"SELECT COUNT(id) AS jmlnormal FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='NORMAL'");
		$hdjmlnormal=mysqli_fetch_array($dtjmlnormal);
		$ttlnormal = $hdjmlnormal['jmlnormal'];
	
			$nbpm=mysqli_query($koneksi,"SELECT * FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='NORMAL' ORDER BY id ASC");
			while($r1=mysqli_fetch_array($nbpm)){
			
				$nilai_bpm = $r1['nilai_bpm'];
				$bpm_min_average = $nilai_bpm - $hslavgn;
				$bpm_min_average_pdua = $bpm_min_average * $bpm_min_average;
				
				mysqli_query($koneksi,"INSERT INTO standar_deviasi(unik_pasien,kelas_deviasi,n_bpm,n_average,bpm_min_average,bpm_min_average_pdua)
								  VALUES('$kd_proses','NORMAL','$nilai_bpm','$hslavgn','$bpm_min_average','$bpm_min_average_pdua')");
				
				$sumnormal=mysqli_query($koneksi,"SELECT SUM(bpm_min_average_pdua) AS sunormal FROM standar_deviasi WHERE unik_pasien='$kd_proses' AND kelas_deviasi='NORMAL'");
				$hsumnormal=mysqli_fetch_array($sumnormal);

				$ttlsumnormal = sqrt($hsumnormal['sunormal'] / $ttlnormal);
								  
				mysqli_query($koneksi,"UPDATE data_pasien SET n_deviasi_normal = '$ttlsumnormal' WHERE unik_pasien  = '$kd_proses'");
			
			}	
	}else
	{			
	            $ttlsumnormal = "1";
				mysqli_query($koneksi,"UPDATE data_pasien SET n_deviasi_normal = '1' WHERE unik_pasien  = '$kd_proses'");
	
	}
		
		

	$cek2=mysqli_query($koneksi,"SELECT * FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='TIDAK NORMAL'");
    $ketemu2=mysqli_num_rows($cek2);
	if ($ketemu2 > 0){

		$dtjmltnormal=mysqli_query($koneksi,"SELECT COUNT(id) AS jmltnormal FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='TIDAK NORMAL'");
		$hdjmltnormal=mysqli_fetch_array($dtjmltnormal);
		$ttltnormal = $hdjmltnormal['jmltnormal'];
	
		$nbpm2=mysqli_query($koneksi,"SELECT * FROM hsl_bpm WHERE unik='$kd_proses' AND kelas_bpm='TIDAK NORMAL' ORDER BY id ASC");
		while($r2=mysqli_fetch_array($nbpm2)){
		
			$nilai_bpm2 = $r2['nilai_bpm'];
			$bpm_min_average2 = $nilai_bpm2 - $hslavgtn;
			$bpm_min_average_pdua2 = $bpm_min_average2 * $bpm_min_average2;
			
			mysqli_query($koneksi,"INSERT INTO standar_deviasi(unik_pasien,kelas_deviasi,n_bpm,n_average,bpm_min_average,bpm_min_average_pdua)
							  VALUES('$kd_proses','TIDAK NORMAL','$nilai_bpm2','$hslavgtn','$bpm_min_average2','$bpm_min_average_pdua2')");
							  
			$sumtnormal=mysqli_query($koneksi,"SELECT SUM(bpm_min_average_pdua) AS sutnormal FROM standar_deviasi WHERE unik_pasien='$kd_proses' AND kelas_deviasi='TIDAK NORMAL'");
			$hsumtnormal=mysqli_fetch_array($sumtnormal);
		
			$ttlsumtnormal = sqrt($hsumtnormal['sutnormal'] / $ttltnormal);
								  
			mysqli_query($koneksi,"UPDATE data_pasien SET n_deviasi_tdknormal = '$ttlsumtnormal' WHERE unik_pasien  = '$kd_proses'");

		}
		
	}else
	{
			$ttlsumtnormal = "1";
			mysqli_query($koneksi,"UPDATE data_pasien SET n_deviasi_tdknormal = '1' WHERE unik_pasien  = '$kd_proses'");
				 
	}
	



		$jmldata=mysqli_query($koneksi,"SELECT COUNT(id) AS jmldatanya FROM hsl_bpm WHERE unik='$kd_proses'");
		$hjmldata=mysqli_fetch_array($jmldata);
		
		$ttlhjmldata = $hjmldata['jmldatanya'];

		$probnormal = $ttlnormal / $ttlhjmldata;
		mysqli_query($koneksi,"INSERT INTO probabilitas(unik_pasien,kelas_probabilitas,n_probabilitas)
								  VALUES('$kd_proses','NORMAL','$probnormal')");
								  
		$probtnormal = $ttltnormal / $ttlhjmldata;
		mysqli_query($koneksi,"INSERT INTO probabilitas(unik_pasien,kelas_probabilitas,n_probabilitas)
								  VALUES('$kd_proses','TIDAK NORMAL','$probtnormal')");
								  
		$jumlahprob = $probnormal + $probtnormal;
		mysqli_query($koneksi,"INSERT INTO probabilitas(unik_pasien,kelas_probabilitas,n_probabilitas)
								  VALUES('$kd_proses','JUMLAH','$jumlahprob')");

					
								  
		

		$n2 = sqrt(2 * 3.14 * $ttlsumnormal);
		$tmp1 = $probnormal - $hslavgn;
		$n3 = pow($tmp1,2);
		$n4 = (2*(($ttlsumnormal) * $ttlsumnormal));
		$n5 = $n3 / $n4;
		$n6 = exp($n5);
		$n7 = $n2 * $n6;
		$n8 = 1 / $n7;
		
		$n2a = sqrt(2 * 3.14 * $ttlsumtnormal);
		$tmp1a = $probtnormal - $hslavgtn;
		$n3a = pow($tmp1a,2);
		$n4a = (2*(($ttlsumtnormal) * $ttlsumtnormal));
		$n5a = $n3a / $n4a;
		$n6a = exp($n5a);
		$n7a = $n2a * $n6a;
		$n8a = 1 / $n7a;
		

		mysqli_query($koneksi,"INSERT INTO gausian(unik_pasien,kelas_gausian,n_gausian)
								  VALUES('$kd_proses','NORMAL','$n8')");
		mysqli_query($koneksi,"INSERT INTO gausian(unik_pasien,kelas_gausian,n_gausian)
								  VALUES('$kd_proses','TIDAK NORMAL','$n8a')");
								  
		if($n8 > $n8a){
		
		mysqli_query($koneksi,"UPDATE data_pasien SET kesimpulan = 'NORMAL' WHERE unik_pasien  = '$kd_proses'");
		
		}else
		{
		
		mysqli_query($koneksi,"UPDATE data_pasien SET kesimpulan = 'TIDAK NORMAL' WHERE unik_pasien  = '$kd_proses'");
		
		}
		
		// }
	
		header('location:media_admin.php?module=hasil&kd_proses='.$kd_proses);
?>