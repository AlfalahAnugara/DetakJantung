<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/class_paging.php";
include "../../../configurasi/koneksi.php";
// include "modul/mod_histori/aksi_histori.php";
// include "masuk/modul/mod_histori/aksi_histori.php";

$aksi="modul/mod_histori/aksi_histori.php";
$aksi_histori = "masuk/modul/mod_histori/aksi_histori.php";
switch($_GET[act]){
  default:
      $tampil_histori = mysqli_query($koneksi,"SELECT * FROM data_pasien");
	  $no=1;
	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">RIWAYAT PEMERIKSAAN</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
					<a  class ='btn  btn-success btn-flat' href='?module=home'>TAMBAH</a>
					<br><br><br>
					
					
					<table id="example1" class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<th>Kode</th>
								<th>Nama Pasien</th>
								<th>Usia</th>
								<th>Kesimpulan</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
						<?php while ($data = mysqli_fetch_array($tampil_histori)) { ?>
							<tr>
								<td><?php echo $no++; ?></td>
								<td><?php echo $data['unik_pasien']; ?></td>
								<td><?php echo $data['nama_pasien']; ?></td>
								<td><?php echo $data['usia_pasien']; ?></td>
								<td><?php echo $data['kesimpulan']; ?></td>
								<td>
									<a href="?module=hasil&kd_proses=<?php echo $data['unik_pasien']; ?>" class="btn btn-warning"><i class=" fa fa-eye"></i> VIEW</a>
									<a onclick="return confirm('Anda yakin ingin menghapus data ini...?')" href="?module=deletehistori&id=<?php echo $data['unik_pasien']; ?>" class="btn btn-danger"><i class=" fa fa-trash"></i> HAPUS</a>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						</table>


						<?php 
								
					

             


    



}
}
?>