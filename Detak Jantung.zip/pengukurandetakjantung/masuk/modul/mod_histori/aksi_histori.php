<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";
include "../../../configurasi/fungsi_thumb.php";
include "../../../configurasi/library.php";
if ($koneksi->connect_error) {
  die("Connection failed: " . $koneksi->connect_error);
}
  mysqli_query($koneksi, "DELETE FROM data_pasien WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi, "DELETE FROM gausian WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi, "DELETE FROM hsl_bpm WHERE unik = '$_GET[id]'");
  mysqli_query($koneksi, "DELETE FROM mean WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi, "DELETE FROM probabilitas WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi, "DELETE FROM standar_deviasi WHERE unik_pasien = '$_GET[id]'");
  
  
}
?>
<h4>Selamat Riwayat <?php echo $_GET['id'] ?> Berhasil Dihapus</h4>
<a  class ='btn  btn-info btn-flat' href='?module=histori'>Kembali</a>
