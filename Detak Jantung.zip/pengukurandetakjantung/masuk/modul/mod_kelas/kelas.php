<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{
include "../../../configurasi/class_paging.php";
include "../../../configurasi/koneksi.php";

switch($_GET[act]){
  default:
  
  for($i=1; $i<=100; $i++){
  $b = rand(70,200);
  mysqli_query($koneksi, "INSERT INTO simsen(hsl)
	                     VALUES('$b')");
  }

  for($i=1; $i<=100; $i++){
	$a = rand(0,500);
	mysqli_query($koneksi, "INSERT INTO ekg(nilai)
						   VALUES('$a')");
	}
   			 					 
     $tampil_katpro = mysqli_query($koneksi, "SELECT * FROM kelas");
      
	  ?>
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">DATA KELAS</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body"><br>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<th>Kelas</th>
								<th>6-10 tahun</th>
								<th>11-14 tahun</th>
								<th>> 15 tahun</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no=1;
								while ($r=mysqli_fetch_array($tampil_katpro)){
									echo "<tr class='warnabaris' >
											<td>$no</td>           
											 <td>$r[nm_kelas]</td>
											 <td>$r[kualifikasi_satu]</td>
											 <td>$r[kualifikasi_dua]</td>
											 <td>$r[kualifikasi_tiga]</td>
										</tr>";
								$no++;
								}
						echo "</tbody></table>";
					?>
				</div>
			</div>	
             

<?php
    
    break;
	
}
}
?>