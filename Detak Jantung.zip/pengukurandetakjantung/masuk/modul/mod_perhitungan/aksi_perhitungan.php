<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/koneksi.php";

include "/masuk/modul/mod_perhitungan/aksi_perhitungan.php";
switch($_GET[act]){
  default:
      $tampil_histori = mysqli_query($koneksi,"SELECT * FROM data_pasien WHERE nama_pasien = 'Alfalah Anugara'");
      $get_pasien = mysqli_query($koneksi,"SELECT DISTINCT nama_pasien FROM data_pasien");
	  $no=1;
	  $noo=1;
	  $noPrediction=1;
	  $arrayHasilNormal_n = array();
	  $arrayHasilNormal_tn = array();
	  $arrayHasilTidakNormal_n = array();
	  $arrayHasilTidakNormal_tn = array();

	  $deviasiNormal = mysqli_query($koneksi, "SELECT n_deviasi_normal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
	  $deviasiTidakNormal = mysqli_query($koneksi, "SELECT n_deviasi_tdknormal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
	  $deviasiPasien = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");

	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">PERHITUNGAN NAÏVE BAYES CLASSIFER</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
				<div class="row">
					<div class="col-lg-6">
					<h4>Pasien : <?php echo $_GET['pasien'] ?></h4>
					</div>
					<div class="col-lg-6 pull-right">
					<a  class ='btn  btn-info btn-flat' href='?module=perhitungan'>KEMBALI</a>
					</div>
				</div>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<th>Deviasi Normal</th>
								<th>Normal</th>
								<th>Tidak Normal</th>
							</tr>
						</thead>
						<tbody>
							<?php while ($data = mysqli_fetch_array($deviasiNormal)) { ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['n_deviasi_normal']; ?></td>
									<td>
										<?php
											$cariDeviasiNormal_n = mysqli_query($koneksi, "SELECT n_deviasi_normal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND n_deviasi_normal = $data[n_deviasi_normal]");
											$countDeviasiNormal_n = mysqli_num_rows($cariDeviasiNormal_n);

											$cariKesimpulan_n = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND (n_deviasi_normal = $data[n_deviasi_normal] AND kesimpulan = 'NORMAL')");
											$countKesimpulan_n = mysqli_num_rows($cariKesimpulan_n);
											
											if ($countDeviasiNormal_n == $countKesimpulan_n) {
												$hasilNormal_n = 1+1;
											}else{
												$hasilNormal_n = 0+1;
											}
											$arrayHasilNormal_n[] = $hasilNormal_n;
											$totalHasilNormal_n += $hasilNormal_n;
											echo $hasilNormal_n;
										?>
									  </td>
									  <td>
										<?php
											$cariDeviasiTidakNormal_n = mysqli_query($koneksi, "SELECT n_deviasi_normal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND n_deviasi_normal = $data[n_deviasi_normal]");
											$countDeviasiTidakNormal_n = mysqli_num_rows($cariDeviasiTidakNormal_n);

											$cariKesimpulanTidakNormal_n = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND (n_deviasi_normal = $data[n_deviasi_normal] AND kesimpulan = 'TIDAK NORMAL')");
											$countKesimpulanTidakNormal_n = mysqli_num_rows($cariKesimpulanTidakNormal_n);
											
											if ($countDeviasiTidakNormal_n == $countKesimpulanTidakNormal_n) {
												$hasilTidakNormal_n = 1+1;
											}else{
												$hasilTidakNormal_n = 0+1;
											}
											$arrayHasilTidakNormal_n[] = $hasilTidakNormal_n;
											$totalHasilTidakNormal_n += $hasilTidakNormal_n;
											echo $hasilTidakNormal_n;
										?>
									  </td>
								</tr>
							<?php } ?>
								<tr>
									<td align="center" colspan="2"><b>TOTAL</b></td>
									<td><?= $totalHasilNormal_n ?></td>
									<td><?= $totalHasilTidakNormal_n ?></td>
								</tr>
						</tbody>
					</table>
					<br><br>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<th>Deviasi Tidak Normal</th>
								<th>Normal</th>
								<th>Tidak Normal</th>
							</tr>
						</thead>
						<tbody>
							<?php while ($data = mysqli_fetch_array($deviasiTidakNormal)) { ?>
									<tr>
										<td><?php echo $noo++; ?></td>
										<td><?php echo $data['n_deviasi_tdknormal']; ?></td>
										<td>
											<?php
												$cariDeviasiNormal_tn = mysqli_query($koneksi, "SELECT n_deviasi_tdknormal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND n_deviasi_tdknormal = $data[n_deviasi_tdknormal]");
												$countDeviasiNormal_tn = mysqli_num_rows($cariDeviasiNormal_tn);

												$cariKesimpulan_tn = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND (n_deviasi_tdknormal = $data[n_deviasi_tdknormal] AND kesimpulan = 'NORMAL')");
												$countKesimpulan_tn = mysqli_num_rows($cariKesimpulan_tn);
												
												if ($countDeviasiNormal_tn == $countKesimpulan_tn) {
													$hasilNormal_tn = 1+1;
												}else{
													$hasilNormal_tn = 0+1;
												}
												$arrayHasilNormal_tn[] = $hasilNormal_tn;
												$totalHasilNormal_tn += $hasilNormal_tn;
												echo $hasilNormal_tn;
											?>
										</td>
										<td>
											<?php
												$cariDeviasiTidakNormal_tn = mysqli_query($koneksi, "SELECT n_deviasi_tdknormal FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND n_deviasi_tdknormal = $data[n_deviasi_tdknormal]");
												$countDeviasiTidakNormal_tn = mysqli_num_rows($cariDeviasiTidakNormal_tn);

												$cariKesimpulanTidakNormal_tn = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND (n_deviasi_tdknormal = $data[n_deviasi_tdknormal] AND kesimpulan = 'TIDAK NORMAL')");
												$countKesimpulanTidakNormal_tn = mysqli_num_rows($cariKesimpulanTidakNormal_tn);
												
												if ($countDeviasiTidakNormal_tn == $countKesimpulanTidakNormal_tn) {
													$hasilTidakNormal_tn = 1+1;
												}else{
													$hasilTidakNormal_tn = 0+1;
												}
												$arrayHasilTidakNormal_tn[] = $hasilTidakNormal_tn;
												$totalHasilTidakNormal_tn += $hasilTidakNormal_tn;
												echo $hasilTidakNormal_tn;
											?>
										</td>
									</tr>
								<?php } ?>
								<tr>
									<td align="center" colspan="2"><b>TOTAL</b></td>
									<td><?= $totalHasilNormal_tn ?></td>
									<td><?= $totalHasilTidakNormal_tn ?></td>
								</tr>
						</tbody>
					</table>
			<br><br>
			<h4>PROBABILITAS</h4>
			<table class="table table-bordered table-striped" >
				<thead>
					<tr>
						<th>Normal</th>
						<th>Tidak Normal</th>
					</tr>
				</thead>
				<tbody>
				<tr>
					<td>
						<?php
							$probNormal1 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND kesimpulan = 'NORMAL'");
							$probNormal2 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
							$countProbNormal1 = mysqli_num_rows($probNormal1);
							$countProbNormal2 = mysqli_num_rows($probNormal2);
							$hasilProbNormal = $countProbNormal1/$countProbNormal2;
							echo $hasilProbNormal;	
						?>
					</td>
					<td>
						<?php
							$probTidakNormal1 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND kesimpulan = 'TIDAK NORMAL'");
							$probTidakNormal2 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
							$countProbTidakNormal1 = mysqli_num_rows($probTidakNormal1);
							$countProbTidakNormal2 = mysqli_num_rows($probTidakNormal2);
							$hasilProbTidakNormal = $countProbTidakNormal1/$countProbTidakNormal2;
							echo $hasilProbTidakNormal;	
						?>
					</td>
				</tr>
				<tr>
					<td><?php echo $hasilProbNormal*100 .'%';  ?></td>
					<td><?php echo $hasilProbTidakNormal*100 .'%';  ?></td>
				</tr>
				</tbody>
			</table>
			<br>
			<table class="table table-bordered table-striped" >
				<thead>
					<tr>
						<th>Nama Pasien</th>
						<th>Normal</th>
						<th>Tidak Normal</th>
					</tr>
				</thead>
				<tbody>
				<tr>
					<td><?php echo $_GET['pasien'] ?></td>
					<td>
						<?php
							$probNormals1 = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND kesimpulan = 'NORMAL'");
							$countProbNormals1 = mysqli_num_rows($probNormals1);
							$hasilProbNormals = $countProbNormals1+1;
							echo $hasilProbNormals;	
						?>
					</td>
					<td>
						<?php
							$probTidakNormals1 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]' AND kesimpulan = 'TIDAK NORMAL'");
							
							$countProbTidakNormals1 = mysqli_num_rows($probTidakNormals1);
							$hasilProbTidakNormals = $countProbTidakNormal1+1;
							echo $hasilProbTidakNormals;	
						?>
					</td>
				</tr>
				</tbody>
			</table>
			<br><br>

			<h4>PREDICTION</h4>
			<table class="table table-bordered table-striped" >
				<thead>
					<tr>
						<th>No</th>
						<th>Nama Pasien</th>
						<th>Deviasi Normal</th>
						<th>Deviasi Tidak Normal</th>
						<th>Kesimpulan</th>
						<th>Normal</th>
						<th>Tidak Normal</th>
						<th>Class Prediction</th>
					</tr>
				</thead>
				<tbody>
					<?php 
						$arrayKey = 0;
						$arrayClassPrediction = array(); ?>
					<?php while ($data = mysqli_fetch_array($deviasiPasien)) { ?>
						<tr>
							<td><?php echo $noPrediction++; ?></td>
							<td><?php echo $data['nama_pasien']; ?></td>
							<td><?php echo $data['n_deviasi_normal']; ?></td>
							<td><?php echo $data['n_deviasi_tdknormal']; ?></td>
							<td><?php echo $data['kesimpulan']; ?></td>
							<td style="background-color:lightgray;">
							<?php 
								$predictionNormal1 = $hasilProbNormals;
								$predictionNormal2 = $arrayHasilNormal_n[$arrayKey];
								$predictionNormal3 = $arrayHasilNormal_tn[$arrayKey];
								$hasilPredictionNormal = $predictionNormal1*$predictionNormal2*$predictionNormal3*$hasilProbNormal;
								echo $hasilPredictionNormal;
							 ?>
							 </td>
							<td style="background-color:lightgray;">
							<?php 
								$predictionTidakNormal1 = $hasilProbTidakNormals;
								$predictionTidakNormal2 = $arrayHasilTidakNormal_n[$arrayKey];
								$predictionTidakNormal3 = $arrayHasilTidakNormal_tn[$arrayKey];
								$hasilPredictionTidakNormal = $predictionTidakNormal1*$predictionTidakNormal2*$predictionTidakNormal3*$hasilProbTidakNormal;
								echo $hasilPredictionTidakNormal;
							 ?>
							 </td>
							 <td style="background-color:lightgray;">
								<?php if ($hasilPredictionNormal > $hasilPredictionTidakNormal) {
									 $hasilClassPrediction =  'NORMAL';
									 echo $hasilClassPrediction;
								}else{
									$hasilClassPrediction =  'TIDAK NORMAL';
									echo $hasilClassPrediction;
								} 
								$arrayClassPrediction[] = $hasilClassPrediction;
								?>
							 </td>
							<?php $arrayKey++ ?>
						</tr>
					<?php } ?>
				</tbody>
			</table>

			<br><br>
			<h4>CONFUSSION MATRIX</h4>
			<table class="table table-bordered table-striped" >
				<thead>
					<tr>
						<th class="text-center" rowspan="2">Predicted </th>
						<th class="text-center" colspan="2">Class</th>
					</tr>
					<tr>
						<th class="text-center bg-info">Normal</th>
						<th class="text-center bg-warning">Tidak Normal</th>
					</tr>
				</thead>
				<tbody>
					<tr class="text-center">
						<td class="bg-info">Normal</td>
						<?php 
								$cariKesimpulan = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
								$cariKesimpulan2 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
								$cariKesimpulan3 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
								$cariKesimpulan4 = mysqli_query($koneksi, "SELECT kesimpulan FROM data_pasien WHERE nama_pasien = '$_GET[pasien]'");
								
								
									$hasilPredictionNormal1 = 0;
									$key=0;
									while ($kesimpulan = mysqli_fetch_array($cariKesimpulan)) {
										if ($arrayClassPrediction[$key] == 'NORMAL') {
											
											if ($kesimpulan['kesimpulan'] == 'NORMAL') {
												$hasilPredictionNormal1++;
											}
										}
									$key++;
									}
									$hasilPredictionNormal1;


									$hasilPredictionNormal2 = 0;
									$key2=0;
									while ($kesimpulan = mysqli_fetch_array($cariKesimpulan2)) {
										if ($arrayClassPrediction[$key2] == 'TIDAK NORMAL') {
											
											if ($kesimpulan['kesimpulan'] == 'TIDAK NORMAL') {
												$hasilPredictionNormal2++;
											}
										}
									$key2++;
									}
									$hasilPredictionNormal2;


									$hasilPredictionNormal3 = 0;
									$key3=0;
									while ($kesimpulan = mysqli_fetch_array($cariKesimpulan3)) {
										if ($arrayClassPrediction[$key3] == 'TIDAK NORMAL') {
											
											if ($kesimpulan['kesimpulan'] == 'NORMAL') {
												$hasilPredictionNormal3++;
											}
										}
									$key3++;
									}
									$hasilPredictionNormal3;

									
									$hasilPredictionNormal4 = 0;
									$key4=0;
									while ($kesimpulan = mysqli_fetch_array($cariKesimpulan4)) {
										if ($arrayClassPrediction[$key4] == 'NORMAL') {

											if ($kesimpulan['kesimpulan'] == 'TIDAK NORMAL') {
												$hasilPredictionNormal4++;
											}
										}
									$key4++;
									}
									$hasilPredictionNormal4;
									$allPrediction = $hasilPredictionNormal1+$hasilPredictionNormal2+$hasilPredictionNormal3+$hasilPredictionNormal4;
									$accuracy = ($hasilPredictionNormal1+$hasilPredictionNormal4)/$allPrediction;

						?>
						<td><?php echo $hasilPredictionNormal1 ?></td>
						<td><?php echo $hasilPredictionNormal2 ?></td>
					</tr>
					<tr class="text-center">
						<td class="bg-warning">Tidak Normal</td>
						<td><?php echo $hasilPredictionNormal3 ?></td>
						<td><?php echo $hasilPredictionNormal4 ?></td>
					</tr>
				</tbody>
			</table>
			<br><br>

			<h4>ACCURACY : <?php echo $accuracy*100 . '%' ?></h4>
			
<?php 

}
}
?>