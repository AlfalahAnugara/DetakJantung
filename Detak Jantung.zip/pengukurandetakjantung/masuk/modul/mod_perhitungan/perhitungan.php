<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/koneksi.php";
include "../../../configurasi/class_paging.php";

include "/masuk/modul/mod_perhitungan/aksi_perhitungan.php";
switch($_GET[act]){
  default:
      $tampil_histori = mysqli_query($koneksi,"SELECT * FROM data_pasien WHERE nama_pasien = 'Alfalah Anugara'");
      $get_pasien = mysqli_query($koneksi,"SELECT DISTINCT nama_pasien FROM data_pasien");
	  $no=1;

	  if (isset($_GET['pasien'])) {
		$pasien = mysqli_query($koneksi,"SELECT DISTINCT nama_pasien FROM data_pasien");
		$result_array = mysqli_fetch_array($result_array);
		header('Content-type: application/json');
		echo json_encode($result_array);
	  }

	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">PERHITUNGAN NAÏVE BAYES CLASSIFER</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
					<table class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Pasien</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php while ($data = mysqli_fetch_array($get_pasien)) { ?>
							<tr>
								<td><?php echo $no++; ?></td>
								<td><?php echo $data['nama_pasien']; ?></td>
								<td>
									<a href="?module=hitung&pasien=<?php echo $data['nama_pasien']; ?>" class="btn btn-warning"><i class=" fa fa-eye"></i> VIEW</a>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						</table>


						<?php 

}
}
?>