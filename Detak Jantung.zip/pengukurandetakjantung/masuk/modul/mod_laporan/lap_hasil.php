<?php
include "../../../configurasi/koneksi.php";
require('../../assets/pdf/fpdf.php');
include "../../../configurasi/fungsi_indotgl.php";
include "../../../configurasi/koneksi.php";

$pdf = new FPDF("P","cm","A4");

$pdf->SetMargins(2,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();

$tampil_dp = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_pasien ASC");
$rx=mysqli_fetch_array($tampil_dp);

$pdf->ln(0);
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,0,'HASIL PROSES NAIVE BAYES',0,0,'C');

//KIRI 1
$pdf->ln(1.5);
$pdf->SetFont('Arial','',10);
$pdf->Cell(3,0,'Kode Proses',0,0,'L');
$pdf->Cell(0.5,0,':',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(1,0,$rx['unik_pasien'],0,0,'L');

$pdf->ln(0.5);
$pdf->SetFont('Arial','',10);
$pdf->Cell(3,0,'Nama Pasien',0,0,'L');
$pdf->Cell(0.5,0,':',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(1,0,$rx['nama_pasien'],0,0,'L');

$pdf->ln(0.5);
$pdf->SetFont('Arial','',10);
$pdf->Cell(3,0,'Usia Pasien',0,0,'L');
$pdf->Cell(0.5,0,':',0,0,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(1,0,$rx['usia_pasien']." Tahun",0,0,'L');

$pdf->ln(1);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"DATA AWAL [BPM SENSOR]",0,10,'L');
$pdf->ln(0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Kelas', 1, 0, 'L');
$pdf->Cell(12.5, 0.8, 'BPM', 1, 1, 'C');
$pdf->SetFont('Arial','',9);
$no1=1;
$query1=mysqli_query($koneksi, "SELECT * FROM hsl_bpm WHERE unik = '$_GET[kd_proses]' ORDER BY id ASC");
while($r1=mysqli_fetch_array($query1)){

	$pdf->Cell(1, 0.8, $no1 , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $r1['kelas_bpm'], 1, 0,'L');
	$pdf->Cell(12.5, 0.8, $r1['nilai_bpm'],1, 1, 'C');

	$no1++;
}


$pdf->ln(0.5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"MEAN",0,10,'L');
$pdf->ln(0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Kelas', 1, 0, 'L');
$pdf->Cell(12.5, 0.8, 'Mean', 1, 1, 'C');
$pdf->SetFont('Arial','',9);
$no2=1;
$query2=mysqli_query($koneksi,"SELECT * FROM mean WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_mean ASC");
while($r2=mysqli_fetch_array($query2)){

	$pdf->Cell(1, 0.8, $no2 , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $r2['kelas'],1, 0, 'L');
	$pdf->Cell(12.5, 0.8, $r2['n_average'], 1, 1,'C');

	$no2++;
}

$pdf->ln(0.5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"STANDAR DEVIASI [POPULASI]",0,10,'L');
$pdf->ln(0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Kelas', 1, 0, 'L');
$pdf->Cell(2, 0.8, 'xi', 1, 0, 'C');
$pdf->Cell(3.5, 0.8, 'x̄', 1, 0, 'C');
$pdf->Cell(3.5, 0.8, 'xi - x̄', 1, 0, 'C');
$pdf->Cell(3.5, 0.8, '(xi - x̄)²', 1, 1, 'C');
$pdf->SetFont('Arial','',9);
$no3=1;
$query3=mysqli_query($koneksi,"SELECT * FROM standar_deviasi WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_sd ASC");
while($r3=mysqli_fetch_array($query3)){

	$pdf->Cell(1, 0.8, $no3 , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $r3['kelas_deviasi'],1, 0, 'L');
	$pdf->Cell(2, 0.8, $r3['n_bpm'],1, 0, 'C');
	$pdf->Cell(3.5, 0.8, $r3['n_average'],1, 0, 'C');
	$pdf->Cell(3.5, 0.8, $r3['bpm_min_average'],1, 0, 'C');
	$pdf->Cell(3.5, 0.8, $r3['bpm_min_average_pdua'], 1, 1,'C');

	$no3++;
}

$pdf->SetFont('Arial','',9);
$pdf->Cell(9.5, 1.6, 'HASIL', 1, 0, 'C');
$pdf->Cell(3.5, 0.8, 'NORMAL', 1, 0, 'R');
$pdf->Cell(3.5, 0.8, $rx['n_deviasi_normal'], 1, 1, 'C');
$pdf->SetX(11.5);
$pdf->Cell(3.5, 0.8, 'TIDAK NORMAL', 1, 0, 'R');
$pdf->Cell(3.5, 0.8, $rx['n_deviasi_tdknormal'], 1, 1, 'C');


$pdf->ln(0.5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"PROBABILITAS",0,10,'L');
$pdf->ln(0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Kelas', 1, 0, 'L');
$pdf->Cell(12.5, 0.8, 'Probabilitas', 1, 1, 'C');
$pdf->SetFont('Arial','',9);
$no4=1;
$query2=mysqli_query($koneksi,"SELECT * FROM probabilitas WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_probabilitas ASC");
while($r4=mysqli_fetch_array($query2)){

	$pdf->Cell(1, 0.8, $no4 , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $r4['kelas_probabilitas'],1, 0, 'L');
	$pdf->Cell(12.5, 0.8, $r4['n_probabilitas'], 1, 1,'C');

	$no4++;
}

$pdf->ln(0.5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"GAUSIAN",0,10,'L');
$pdf->ln(0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Kelas', 1, 0, 'L');
$pdf->Cell(12.5, 0.8, 'Gausian', 1, 1, 'C');
$pdf->SetFont('Arial','',9);
$no4=1;
$query2=mysqli_query($koneksi,"SELECT * FROM gausian WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_gausian ASC");
while($r4=mysqli_fetch_array($query2)){

	$pdf->Cell(1, 0.8, $no4 , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $r4['kelas_gausian'],1, 0, 'L');
	$pdf->Cell(12.5, 0.8, $r4['n_gausian'], 1, 1,'C');

	$no4++;
}

$pdf->ln(0.5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25.5,0.7,"Kesimpulan hasil pengujian BPM Anda adalah ==>> ".$rx['kesimpulan']." <<==",0,10,'L');




$pdf->Output("laporan_hasil.pdf","I");

?>

