

<style>
.table-condensed {
font-size: 13px;
}

.table-akum {
font-size: 11px;
}

.judul-table{ 
font-weight: bold; 
font-size: 13px;
background-color: black;
color: white;

}
</style>

<style type="text/css">
            .container {
                width: 40%;
                margin: 15px auto;
            }
    </style>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/class_paging.php";
include "../../../configurasi/koneksi.php";

$aksi="modul/mod_hasil/aksi_hasil.php";
$aksi_hasil = "masuk/modul/mod_hasil/aksi_hasil.php";
switch($_GET[act]){
  default:

  
      $tampil_awal = mysqli_query($koneksi, "SELECT * FROM hsl_bpm WHERE unik = '$_GET[kd_proses]' ORDER BY id ASC");
	  $tampil_mean = mysqli_query($koneksi, "SELECT * FROM mean WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_mean ASC");
	  $tampil_sd = mysqli_query($koneksi, "SELECT * FROM standar_deviasi WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_sd ASC");
	  $tampil_dp = mysqli_query($koneksi, "SELECT * FROM data_pasien WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_pasien ASC");
	  $rx=mysqli_fetch_array($tampil_dp);
	  $tampil_pro = mysqli_query($koneksi, "SELECT * FROM probabilitas WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_probabilitas ASC");
	  $tampil_gau = mysqli_query($koneksi, "SELECT * FROM gausian WHERE unik_pasien = '$_GET[kd_proses]' ORDER BY id_gausian ASC");
	//   $ekg = mysqli_query($koneksi, "SELECT * FROM hsl_bpm ORDER BY id ASC");
	  $ekg = mysqli_query($koneksi, "SELECT * FROM ekg ORDER BY id ASC");
	  
      
	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">HASIL PROSES NAIVE BAYES</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
				
				<h3 class="box-title">Kode Proses &nbsp: <?php echo $rx['unik_pasien']; ?></h3>
				<h3 class="box-title">Nama Pasien : <?php echo $rx['nama_pasien']; ?></h3>
				<h3 class="box-title">Usia Pasien &nbsp&nbsp: <?php echo $rx['usia_pasien']; ?> Tahun</h3>
				<br>
				
					<a  class ="btn  btn-success btn-flat" href="modul/mod_laporan/lap_hasil.php?kd_proses=<?php echo $rx['unik_pasien']; ?>" target="_blank">CETAK DATA</a>
					<a  class ='btn  btn-danger btn-flat' href='?module=histori'>KEMBALI</a>
					<br>
					
					<h3 class="box-title">DATA AWAL [BPM SENSOR]</h3>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr class="judul-table">
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">No</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">BPM</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Kelas</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no=1;
								while ($r=mysqli_fetch_array($tampil_awal)){
								
								echo "<tr class='warnabaris' >
											<td align=center>$no</td>           
											 <td align=center>$r[nilai_bpm]</td>
											 <td align=left>$r[kelas_bpm]</td>
											</td>
										</tr>";
								
								$no++;
								}
						echo "</tbody></table>";
					?>
					
					
					
					<br>
					
					<h3 class="box-title">MEAN</h3>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr class="judul-table">
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">No</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Kelas</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Mean</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no1=1;
								while ($r1=mysqli_fetch_array($tampil_mean)){
								
								echo "<tr class='warnabaris' >
											<td align=center>$no1</td>           
											 <td align=left>$r1[kelas]</td>
											 <td align=left>$r1[n_average]</td>
											</td>
										</tr>";
								
								$no1++;
								}
						echo "</tbody></table>";
					?>
					
					
					<br>
					
					<h3 class="box-title">STANDAR DEVIASI [ POPULASI ]</h3>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr class="judul-table">
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">No</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Kelas</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">xi</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">x̄</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">xi - x̄</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">(xi - x̄)²</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no2=1;
								while ($r2=mysqli_fetch_array($tampil_sd)){
								
								echo "<tr class='warnabaris' >
											<td align=center>$no2</td>           
											 <td align=left>$r2[kelas_deviasi]</td>
											 <td align=center>$r2[n_bpm]</td>
											 <td align=center>$r2[n_average]</td>
											 <td align=center>$r2[bpm_min_average]</td>
											 <td align=center>$r2[bpm_min_average_pdua]</td>
											</td>
										</tr>";
								
								$no2++;
								}
						echo "</tbody></table>";
					?>
					<br>
					<h4 class="box-title">Hasil Standar Deviasi Kelas NORMAL adalah : <?php echo $rx['n_deviasi_normal']; ?></h4>
					<h4 class="box-title">Hasil Standar Deviasi Kelas TIDAK NORMAL adalah : <?php echo $rx['n_deviasi_tdknormal']; ?></h4>
					
					<br>
					
					<h3 class="box-title">PROBABILITAS</h3>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr class="judul-table">
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">No</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Kelas</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Probabilitas</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no3=1;
								while ($r3=mysqli_fetch_array($tampil_pro)){
								
								echo "<tr class='warnabaris' >
											<td align=center>$no3</td>           
											 <td align=left>$r3[kelas_probabilitas]</td>
											 <td center=left>$r3[n_probabilitas]</td>
											</td>
										</tr>";
								
								$no3++;
								}
						echo "</tbody></table>";
					?>
					
					
					<br>
					
					<h3 class="box-title">GAUSIAN</h3>
					<table class="table table-bordered table-striped" >
						<thead>
							<tr class="judul-table">
								<th style="vertical-align: middle; background-color: #008000; text-align: center;">No</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Kelas</th>
								<th style="vertical-align: middle; background-color: #008000; text-align: left;">Gausian</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no4=1;
								while ($r4=mysqli_fetch_array($tampil_gau)){
								
								echo "<tr class='warnabaris' >
											<td align=center>$no4</td>           
											 <td align=left>$r4[kelas_gausian]</td>
											 <td center=left>$r4[n_gausian]</td>
											</td>
										</tr>";
								
								$no4++;
								}
						echo "</tbody></table>";
					?>
					
					<h3 class="box-title">KESIMPULAN hasil pengujian BPM anda adalah <?php echo $rx['kesimpulan']; ?></h3>
					
				</div>
			</div>	
			
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">LINE CHART ECG / EKG</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div> <!--/.box-tools-->
				</div>
				<div class="box-body">
				
				 <div id="chartdiv"></div>
					
					
				</div>
			</div>	
             

<?php
    
    break;
}
}
?>

<style>
#chartdiv {
  width: 100%;
  height: 500px;
}

</style>


<!-- Chart code -->
<script type="text/javascript">

am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create chart instance
var chart = am4core.create("chartdiv", am4charts.XYChart);

// Add data
chart.data = generateChartData();

// Create axes
var valueAxis = chart.xAxes.push(new am4charts.ValueAxis());

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

// Create series
var series = chart.series.push(new am4charts.LineSeries());
series.dataFields.valueY = "visits";
series.dataFields.valueX = "date";
series.strokeWidth = 2;
series.minBulletDistance = 10;
series.tooltipText = "{valueY}";
series.tooltip.pointerOrientation = "vertical";
series.tooltip.background.cornerRadius = 20;
series.tooltip.background.fillOpacity = 0.5;
series.tooltip.label.padding(12,12,12,12)

//scrollbars
chart.scrollbarX = new am4core.Scrollbar();
chart.scrollbarY = new am4core.Scrollbar();

// Add cursor
chart.cursor = new am4charts.XYCursor();
chart.cursor.xAxis = valueAxis;
chart.cursor.snapToSeries = series;

function generateChartData() {

//menampilkan name bottom
var chartData2 = [];
	<?php
		while($nekgb=mysqli_fetch_array($ekg)){
		$idnya = $nekgb['id'];
		$ah=mysqli_query($koneksi, "SELECT * FROM ekg WHERE id='$idnya'");
		// $ah=mysql_query("SELECT * FROM hsl_bpm WHERE id='$idnya'");
		$rah=mysqli_fetch_array($ah);
		$nb = $rah['nilai'];
		// $nb = $rah['nilai_bpm'];
	?>
			chartData2.push({
						date: "<?php echo $idnya ?>",
						visits: <?php echo $nb ?>
						});    
			
	<?php } ?>
   
   
    return chartData2;
}

}); // end am4core.ready()
</script>