<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";
include "../../../configurasi/fungsi_thumb.php";
include "../../../configurasi/library.php";
include "../../../configurasi/koneksi.php";


  mysqli_query($koneksi,"DELETE FROM data_pasien WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi,"DELETE FROM gausian WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi,"DELETE FROM hsl_bpm WHERE unik = '$_GET[id]'");
  mysqli_query($koneksi,"DELETE FROM mean WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi,"DELETE FROM probabilitas WHERE unik_pasien = '$_GET[id]'");
  mysqli_query($koneksi,"DELETE FROM standar_deviasi WHERE unik_pasien = '$_GET[id]'");
  
  header('location:../../media_admin.php?module=tabel');
}

?>
