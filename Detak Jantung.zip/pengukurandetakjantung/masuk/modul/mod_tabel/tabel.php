<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/class_paging.php";
include "../../../configurasi/koneksi.php";

$aksi="modul/mod_tabel/aksi_tabel.php";
$aksi_tabel = "masuk/modul/mod_tabel/aksi_tabel.php";
switch($_GET[act]){
  default:

  
      $tampil_histori = mysqli_query($koneksi,"SELECT * FROM data_pasien ORDER BY nama_pasien ASC" );
      
	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">DATA</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
					<a  class ='btn  btn-success btn-flat' href='?module=home'>KEMBALI</a>
					<br><br><br>
					
					
					<table id="example1" class="table table-bordered table-striped" >
						<thead>
							<tr>
								<th>No</th>
								<!-- <th>Kode</th> -->
								<th>Nama Pasien</th>
								<th>Usia</th>
								<th>Deviasi Normal</th>
								<th>Deviasi Tidak Normal</th>
								<th>Kesimpulan</th>
							</tr>
						</thead>
						<tbody>
						<?php 
								$no=1;
								while ($r=mysqli_fetch_array($tampil_histori)){
									echo "<tr class='warnabaris' >
											<td>$no</td>           
											 <td>$r[nama_pasien]</td>
											 <td>$r[usia_pasien]</td>
											 <td>$r[n_deviasi_normal]</td>
											 <td>$r[n_deviasi_tdknormal]</td>
											 <td>$r[kesimpulan]</td>
											 
											</td>z
										</tr>";
								$no++;
								}
							
						echo "</tbody></table>";
					

             


    



}
}
?>