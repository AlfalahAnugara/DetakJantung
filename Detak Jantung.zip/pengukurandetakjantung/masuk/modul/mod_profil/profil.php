<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

include "../../../configurasi/class_paging.php";
include "../../../configurasi/koneksi.php";

switch($_GET[act]){
  default:

  
      $edit=mysqli_query($koneksi,"SELECT * FROM admin");
      $r=mysqli_fetch_array($edit);
      
	  ?>
			
			
			<div class="box box-danger box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">PROFIL</h3>
					<div class="box-tools pull-right">
						<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div><!-- /.box-tools -->
				</div>
				<div class="box-body">
						<form method="POST" action="modul/mod_profil/aksi_profil.php?module=profil&act=ubah_profil"  enctype="multipart/form-data" class="form-horizontal">
							  <input type="hidden" name="id_adminx" value="<?php $r['id_admin']?>">
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Nama Lengkap</label>        		
									 <div class="col-sm-4">
										<input type="text" name="nama_lengkapx" class="form-control" value="<?php echo $r['nama_lengkap']?>">
									 </div>
							  </div>
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Username</label>        		
									 <div class="col-sm-4">
										<input type="text" name="usernamex" class="form-control" value="<?php echo $r['username']?>">
									 </div>
							  </div>
							  
							  <div class="form-group">
									<label class="col-sm-2 control-label">Password</label>        		
									 <div class="col-sm-4">
										<input type="text" name="passwordx" class="form-control" value="<?php echo $r['password']?>">
									 </div>
							  </div>
							  
							  <div class="buttons">
							  <input class="btn btn-primary" type="submit" value="UBAH">
							  <a  class ='btn  btn-danger' href='?module=home'>KEMBALI</a>
							  </div>
							  </form>
							  
				</div> 
				
			</div>	
             

<?php



}
}
?>