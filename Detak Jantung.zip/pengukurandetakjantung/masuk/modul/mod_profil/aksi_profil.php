<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";
include "../../../configurasi/fungsi_thumb.php";
include "../../../configurasi/library.php";
include "../../../configurasi/koneksi.php";

$module=$_GET['module'];
$act=$_GET['act'];
  
      mysqli_query($koneksi,"UPDATE admin SET username 	 = '$_POST[usernamex]',
								    password     = '$_POST[passwordx]',
								    nama_lengkap = '$_POST[nama_lengkapx]'
                              WHERE id_admin     = '3'");
						   
	echo "<script>alert('Ubah data berhasil');window.location='../../media_admin.php?module=profil'</script>";


}
?>
