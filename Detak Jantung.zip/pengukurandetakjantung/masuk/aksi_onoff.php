<?php
include "../configurasi/koneksi.php";

$sttnya = $_GET['stt'];
if($sttnya == "ON"){
	$hsl = "OFF";
}else{
	$hsl = "ON";
}

mysqli_query($koneksi,"UPDATE onoff SET stt = '$hsl' WHERE id = '1'");
						   
	header('location:media_admin.php?module=home');


?>
