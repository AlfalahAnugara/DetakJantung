<?php
include "../configurasi/koneksi.php";

$username = $_POST['username'];
$pass     = $_POST['password'];

$login=mysqli_query($koneksi,"SELECT * FROM admin WHERE username='$username' AND password='$pass'");
$ketemu=mysqli_num_rows($login);
$r=mysqli_fetch_array($login);

if ($ketemu > 0){
  session_start();
  echo $ketemu;
  include "timeout.php";

  $_SESSION['namauser']     = $r['username'];
  $_SESSION['namalengkap']  = $r['nama_lengkap'];
  $_SESSION['passuser']     = $r['password'];
  $_SESSION['leveluser']    = "admin";
  $_SESSION['levelnya']    = "admin";
  $_SESSION['kd_level']    = "1";
  $_SESSION['idadmin']      = $r['id_admin'];

  $_SESSION['login'] = 1;
  timer();

	$sid_lama = session_id();

	session_regenerate_id();

	$sid_baru = session_id();
	
	header('location:media_admin.php?module=home');
  
} else {
   echo "<link href=css/style.css rel=stylesheet type=text/css>";
   echo "<div class='error msg'>Login Gagal, Username atau Password salah, atau account anda sedang di blokir. ";
   echo "<a href=index.php><b>ULANGI LAGI</b></a></center></div>";
}

?>
