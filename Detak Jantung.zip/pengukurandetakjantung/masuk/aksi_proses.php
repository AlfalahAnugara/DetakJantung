<?php
include "../configurasi/koneksi.php";
include "../configurasi/fungsi_thumb.php";
include "../configurasi/library.php";

	$nm_pasien = $_POST['nm_pasien'];
	$usia = $_POST['usia'];
	$kd_proses = $_POST['kd_proses'];
	
	if($nm_pasien == "" && $usia == ""){
	break;
	}else{
	
	 mysqli_query($koneksi,"INSERT INTO data_pasien(unik_pasien,nama_pasien,usia_pasien)
							  VALUES('$kd_proses','$nm_pasien','$usia')");
	
	$ads=mysqli_query($koneksi,"SELECT * FROM simsen ORDER BY id_s ASC");
	$no=1;
	while($r1=mysqli_fetch_array($ads)){
	
	 $hss = $r1['hsl'];
	 $id_s = $r1['id_s'];
	 
	 if($usia >= 6 && $usia <= 10){
	 
		if($hss >= 70 && $hss <= 110){
		$sttbpm = "NORMAL";
		}else{
		$sttbpm = "TIDAK NORMAL";
		}
		
	 } else if($usia >= 11 && $usia <= 14){
	 
	 if($hss >= 60 && $hss <= 105){
		$sttbpm = "NORMAL";
		}else{
		$sttbpm = "TIDAK NORMAL";
		}
		
	 } else if($usia >= 15){
	 
	 if($hss >= 60 && $hss <= 100){
		$sttbpm = "NORMAL";
		}else{
		$sttbpm = "TIDAK NORMAL";
		}
		
	 }else{
	    $sttbpm = "-";
	 }
	 
	 if($sttbpm == "-"){
	 break;
	 }else{
	 
	 mysqli_query($koneksi,"INSERT INTO hsl_bpm(unik,nm_pasien,usia,nilai_bpm,kelas_bpm)
							  VALUES('$kd_proses','$nm_pasien','$usia','$hss','$sttbpm')");
							  
	mysqli_query($koneksi,"DELETE FROM simsen WHERE id_s = '$id_s'");
	 
	 }
	 
	sleep(1);
}
}
?>