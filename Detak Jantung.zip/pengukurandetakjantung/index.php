<?php

header ('location:masuk/index.php');
?>